import { useState, useRef } from "react";
import { Volume2, VolumeX, CloudRain, Coffee, Wind, Zap } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";

// In a real app, these would be actual audio file URLs
// For mockup, we'll just simulate the UI state
const SOUNDS = [
  { id: "rain", name: "Heavy Rain", icon: CloudRain, color: "text-blue-400" },
  { id: "cafe", name: "Cafe Noise", icon: Coffee, color: "text-amber-400" },
  { id: "white", name: "White Noise", icon: Wind, color: "text-gray-400" },
  { id: "lofi", name: "Lo-Fi Beats", icon: Zap, color: "text-purple-400" },
];

export function AmbientPlayer() {
  const [activeSound, setActiveSound] = useState<string | null>(null);
  const [volume, setVolume] = useState([50]);
  const [isMuted, setIsMuted] = useState(false);

  const toggleSound = (id: string) => {
    if (activeSound === id) {
      setActiveSound(null);
    } else {
      setActiveSound(id);
      setIsMuted(false);
    }
  };

  return (
    <div className="glass-panel p-6 rounded-3xl">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-bold font-display text-white flex items-center gap-2">
          <Volume2 className="h-5 w-5 text-primary" />
          Soundscapes
        </h3>
        {activeSound && (
          <button 
            onClick={() => setIsMuted(!isMuted)}
            className="text-muted-foreground hover:text-white transition-colors"
          >
            {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
          </button>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3 mb-6">
        {SOUNDS.map((sound) => (
          <button
            key={sound.id}
            onClick={() => toggleSound(sound.id)}
            className={cn(
              "relative p-4 rounded-xl border text-left transition-all duration-300 overflow-hidden group",
              activeSound === sound.id 
                ? "bg-white/10 border-primary/50 shadow-[0_0_15px_rgba(0,0,0,0.3)]" 
                : "bg-black/20 border-transparent hover:bg-white/5 hover:border-white/10"
            )}
          >
            <div className={cn(
              "absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity bg-gradient-to-br from-white/20 to-transparent"
            )} />
            
            <sound.icon className={cn(
              "h-6 w-6 mb-2 transition-colors duration-300",
              activeSound === sound.id ? sound.color : "text-muted-foreground group-hover:text-white"
            )} />
            
            <div className="text-sm font-medium text-white">{sound.name}</div>
            
            {activeSound === sound.id && !isMuted && (
              <div className="absolute right-3 top-3 flex gap-0.5 h-3 items-end">
                {[1, 2, 3].map((i) => (
                  <div 
                    key={i} 
                    className={cn("w-1 bg-primary/80 rounded-full animate-pulse-glow")}
                    style={{ height: `${Math.random() * 100}%`, animationDelay: `${i * 0.1}s` }} 
                  />
                ))}
              </div>
            )}
          </button>
        ))}
      </div>

      <div className={cn(
        "transition-all duration-300 overflow-hidden",
        activeSound ? "h-auto opacity-100" : "h-0 opacity-0"
      )}>
        <div className="flex items-center gap-3 px-1">
          <Volume2 className="h-4 w-4 text-muted-foreground" />
          <Slider 
            value={volume} 
            onValueChange={setVolume}
            max={100} 
            step={1}
            className="flex-1"
          />
        </div>
      </div>
    </div>
  );
}
