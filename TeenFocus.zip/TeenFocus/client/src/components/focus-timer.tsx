import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Play, Pause, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface FocusTimerProps {
  initialMinutes?: number;
}

export function FocusTimer({ initialMinutes = 25 }: FocusTimerProps) {
  const [minutes, setMinutes] = useState(initialMinutes);
  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<"focus" | "break">("focus");

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isActive) {
      interval = setInterval(() => {
        if (seconds === 0) {
          if (minutes === 0) {
            setIsActive(false);
            // Timer finished
          } else {
            setMinutes(minutes - 1);
            setSeconds(59);
          }
        } else {
          setSeconds(seconds - 1);
        }
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isActive, minutes, seconds]);

  const toggleTimer = () => setIsActive(!isActive);
  
  const resetTimer = () => {
    setIsActive(false);
    setMinutes(mode === "focus" ? 25 : 5);
    setSeconds(0);
  };

  const setFocusMode = () => {
    setMode("focus");
    setMinutes(25);
    setSeconds(0);
    setIsActive(false);
  };

  const setBreakMode = () => {
    setMode("break");
    setMinutes(5);
    setSeconds(0);
    setIsActive(false);
  };

  const progress = mode === "focus" 
    ? ((minutes * 60 + seconds) / (25 * 60)) * 100
    : ((minutes * 60 + seconds) / (5 * 60)) * 100;

  return (
    <div className="glass-panel relative overflow-hidden rounded-3xl p-8 flex flex-col items-center justify-center w-full max-w-md mx-auto border-t border-white/20">
      {/* Mode Switcher */}
      <div className="flex gap-2 mb-8 bg-black/20 p-1 rounded-full">
        <button 
          onClick={setFocusMode}
          className={cn(
            "px-6 py-2 rounded-full text-sm font-bold transition-all duration-300",
            mode === "focus" ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25" : "text-muted-foreground hover:text-white"
          )}
        >
          Focus
        </button>
        <button 
          onClick={setBreakMode}
          className={cn(
            "px-6 py-2 rounded-full text-sm font-bold transition-all duration-300",
            mode === "break" ? "bg-secondary text-white shadow-lg shadow-secondary/25" : "text-muted-foreground hover:text-white"
          )}
        >
          Chill
        </button>
      </div>

      {/* Timer Display */}
      <div className="relative mb-8 group cursor-pointer" onClick={toggleTimer}>
        {/* Glowing Ring Effect behind */}
        <div className={cn(
            "absolute inset-0 rounded-full blur-3xl transition-opacity duration-1000",
            isActive ? "opacity-40" : "opacity-10",
            mode === "focus" ? "bg-primary" : "bg-secondary"
          )} 
        />
        
        <div className="relative z-10 flex items-center justify-center">
          <span className="font-display text-[8rem] leading-none font-bold tracking-tighter tabular-nums select-none text-stroke md:text-[10rem] text-transparent bg-clip-text bg-gradient-to-b from-white to-white/50 drop-shadow-2xl">
            {minutes.toString().padStart(2, "0")}
          </span>
          <span className="font-display text-[4rem] leading-none font-bold text-white/20 mb-4 mx-2">:</span>
          <span className="font-display text-[8rem] leading-none font-bold tracking-tighter tabular-nums select-none text-stroke md:text-[10rem] text-transparent bg-clip-text bg-gradient-to-b from-white to-white/50 drop-shadow-2xl">
            {seconds.toString().padStart(2, "0")}
          </span>
        </div>
        
        {/* Status Indicator */}
        <motion.div 
          animate={{ scale: isActive ? [1, 1.1, 1] : 1 }}
          transition={{ repeat: Infinity, duration: 2 }}
          className={cn(
            "absolute -bottom-4 left-1/2 -translate-x-1/2 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full border",
            isActive ? (mode === "focus" ? "bg-primary text-black border-primary" : "bg-secondary text-white border-secondary") : "bg-transparent text-muted-foreground border-white/10"
          )}
        >
          {isActive ? (mode === "focus" ? "Zone In" : "Zone Out") : "Paused"}
        </motion.div>
      </div>

      {/* Controls */}
      <div className="flex gap-4 items-center">
        <Button 
          variant="outline" 
          size="icon" 
          className="h-14 w-14 rounded-full border-2 hover:bg-white/10 hover:border-white/50 transition-all"
          onClick={resetTimer}
        >
          <RotateCcw className="h-6 w-6" />
        </Button>
        
        <Button 
          size="icon" 
          className={cn(
            "h-20 w-20 rounded-full shadow-xl hover:scale-105 transition-all duration-300",
            mode === "focus" ? "bg-primary text-primary-foreground hover:bg-primary/90" : "bg-secondary text-white hover:bg-secondary/90"
          )}
          onClick={toggleTimer}
        >
          {isActive ? <Pause className="h-10 w-10 fill-current" /> : <Play className="h-10 w-10 fill-current ml-1" />}
        </Button>
      </div>
    </div>
  );
}
