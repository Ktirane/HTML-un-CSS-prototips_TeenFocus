import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Check, Trash2, GripVertical } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface Task {
  id: string;
  text: string;
  completed: boolean;
}

export function TaskStack() {
  const [tasks, setTasks] = useState<Task[]>([
    { id: "1", text: "Read Chapter 4", completed: false },
    { id: "2", text: "Math Practice Set", completed: false },
  ]);
  const [newTask, setNewTask] = useState("");

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.trim()) return;
    
    setTasks([...tasks, { id: Date.now().toString(), text: newTask, completed: false }]);
    setNewTask("");
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const clearCompleted = () => {
    setTasks(tasks.filter(t => !t.completed));
  };

  return (
    <div className="glass-panel p-6 rounded-3xl h-full min-h-[400px] flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-2xl font-display font-bold text-white">Mission Log</h3>
        <span className="text-xs font-mono text-muted-foreground bg-white/5 px-2 py-1 rounded">
          {tasks.filter(t => !t.completed).length} PENDING
        </span>
      </div>

      <form onSubmit={addTask} className="relative mb-6 group">
        <Input 
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="Add new mission..."
          className="bg-black/20 border-white/10 text-white placeholder:text-white/30 rounded-xl h-12 pr-12 focus-visible:ring-primary/50 focus-visible:border-primary transition-all"
        />
        <Button 
          type="submit" 
          size="icon"
          className="absolute right-1 top-1 h-10 w-10 rounded-lg bg-primary/20 text-primary hover:bg-primary hover:text-black transition-colors"
        >
          <Plus className="h-5 w-5" />
        </Button>
      </form>

      <div className="flex-1 overflow-y-auto pr-2 space-y-3 custom-scrollbar">
        <AnimatePresence initial={false} mode="popLayout">
          {tasks.length === 0 ? (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              className="h-full flex flex-col items-center justify-center text-center text-muted-foreground opacity-50 space-y-2"
            >
              <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-2">
                <Check className="h-8 w-8" />
              </div>
              <p>All systems nominal.</p>
              <p className="text-xs">No active missions.</p>
            </motion.div>
          ) : (
            tasks.map((task) => (
              <motion.div
                key={task.id}
                layout
                initial={{ opacity: 0, x: -20, scale: 0.9 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: 20, scale: 0.9 }}
                className={cn(
                  "group relative p-4 rounded-xl border transition-all duration-200 flex items-center gap-3",
                  task.completed 
                    ? "bg-black/20 border-transparent opacity-60" 
                    : "bg-white/5 border-white/10 hover:border-primary/50 hover:bg-white/10"
                )}
              >
                <button
                  onClick={() => toggleTask(task.id)}
                  className={cn(
                    "flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-300",
                    task.completed 
                      ? "bg-primary border-primary text-black" 
                      : "border-white/30 hover:border-primary"
                  )}
                >
                  {task.completed && <Check className="h-3.5 w-3.5 stroke-[3]" />}
                </button>
                
                <span className={cn(
                  "flex-1 font-medium truncate transition-all duration-300",
                  task.completed ? "text-muted-foreground line-through" : "text-white"
                )}>
                  {task.text}
                </span>

                <button
                  onClick={() => deleteTask(task.id)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive p-1"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>

      {tasks.some(t => t.completed) && (
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={clearCompleted}
          className="mt-4 text-xs text-muted-foreground hover:text-white hover:bg-white/5 self-center"
        >
          Clear completed
        </Button>
      )}
    </div>
  );
}
