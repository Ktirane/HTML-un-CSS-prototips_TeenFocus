import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Menu, X, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { href: "/", label: "Sākums" },
    { href: "/about", label: "Par mums" },
    { href: "/methods", label: "Metodes" },
    { href: "/contact", label: "Kontakti" },
  ];

  return (
    <div className="min-h-screen flex flex-col font-sans text-foreground bg-transparent">
      <header className="sticky top-0 z-50 border-b border-white/10 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          {/* Logo */}
          <Link href="/">
            <a className="flex items-center gap-2 group">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center rotate-3 group-hover:rotate-12 transition-transform duration-300 shadow-[0_0_15px_hsl(var(--primary))]">
                <div className="w-3 h-3 bg-black rounded-full" />
              </div>
              <span className="text-xl font-display font-black tracking-tighter text-white">
                Focus<span className="text-primary">Teen</span>
              </span>
            </a>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <a
                  className={cn(
                    "text-sm font-bold uppercase tracking-wide transition-colors hover:text-primary relative",
                    location === item.href ? "text-primary" : "text-muted-foreground"
                  )}
                >
                  {item.label}
                  {location === item.href && (
                    <span className="absolute -bottom-6 left-0 right-0 h-0.5 bg-primary shadow-[0_0_10px_hsl(var(--primary))]" />
                  )}
                </a>
              </Link>
            ))}
          </nav>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden p-2 text-white hover:text-primary transition-colors"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Nav Dropdown */}
        {isMobileMenuOpen && (
          <nav className="md:hidden border-t border-white/10 bg-black/90 backdrop-blur-xl absolute top-16 left-0 right-0 p-4 flex flex-col gap-4 shadow-2xl animate-in slide-in-from-top-5">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <a
                  className={cn(
                    "text-lg font-display font-bold py-2 px-4 rounded-lg hover:bg-white/5 transition-colors",
                    location === item.href ? "text-primary bg-primary/10" : "text-white"
                  )}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </a>
              </Link>
            ))}
            <Button className="w-full mt-2 font-bold">Izmēģiniet to tūlīt</Button>
          </nav>
        )}
      </header>

      <main className="flex-1 relative z-10">
        {children}
      </main>

      <footer className="border-t border-white/10 bg-black/40 backdrop-blur-sm py-12 mt-auto relative z-10">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
          <div className="space-y-4">
            <div className="flex items-center justify-center md:justify-start gap-2">
              <div className="w-6 h-6 bg-primary rounded-md flex items-center justify-center rotate-3">
                <div className="w-2 h-2 bg-black rounded-full" />
              </div>
              <span className="text-lg font-display font-black text-white">
                Focus<span className="text-primary">Teen</span>
              </span>
            </div>
            <p className="text-sm text-muted-foreground">
              Vienkārši vingrinājumi pusaudžiem, lai palīdzētu koncentrēties.
            </p>
          </div>
          
          <div>
            <h4 className="font-bold text-white mb-4">Izvēlne</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/"><a className="hover:text-primary">Sākums</a></Link></li>
              <li><Link href="/about"><a className="hover:text-primary">Par mums</a></Link></li>
              <li><Link href="/methods"><a className="hover:text-primary">Metodes</a></Link></li>
              <li><Link href="/contact"><a className="hover:text-primary">Kontakti</a></Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white mb-4">Sociālie tīkli</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Instagram: FocusTeen</li>
              <li>TikTok: FocusTeen</li>
            </ul>
          </div>
        </div>
        <div className="container mx-auto px-4 mt-12 pt-8 border-t border-white/5 text-center text-xs text-muted-foreground">
          &copy; 2024 FocusTeen. Visas tiesības aizsargātas.
        </div>
      </footer>
    </div>
  );
}
