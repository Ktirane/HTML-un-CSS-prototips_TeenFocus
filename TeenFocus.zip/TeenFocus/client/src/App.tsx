import { Switch, Route } from "wouter";
import { Home } from "@/pages/home";
import { About } from "@/pages/about";
import { Methods } from "@/pages/methods";
import { Contact } from "@/pages/contact";
import NotFound from "@/pages/not-found";
import { Toaster } from "@/components/ui/toaster";
import bgImage from "@assets/generated_images/abstract_3d_focus_background_with_lime_and_purple_shapes.png";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/about" component={About} />
      <Route path="/methods" component={Methods} />
      <Route path="/contact" component={Contact} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <div className="min-h-screen w-full bg-background text-foreground relative selection:bg-primary selection:text-black">
      {/* Global Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-background/85 z-10 backdrop-blur-[2px]" />
        <img 
          src={bgImage} 
          alt="Background" 
          className="w-full h-full object-cover opacity-60"
        />
        {/* Grain Overlay */}
        <div className="absolute inset-0 opacity-[0.03] z-20 pointer-events-none mix-blend-overlay" 
             style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` }} 
        />
      </div>

      <Router />
      <Toaster />
    </div>
  );
}

export default App;
