import { Layout } from "@/components/layout";

export function About() {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-display font-black text-white mb-12">
            Par <span className="text-primary">mums</span>
          </h1>
          
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-10 rounded-3xl shadow-2xl">
            <p className="text-2xl md:text-3xl font-light leading-relaxed text-white/90">
              "Mēs izveidojām FocusTeen, lai palīdzētu pusaudžiem labāk pārvaldīt savu uzmanību un mācību prasmes. Vienkārši un bezmaksas vingrinājumi."
            </p>
          </div>
        </div>
      </div>
    </Layout>
  );
}
