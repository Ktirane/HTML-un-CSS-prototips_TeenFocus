import { Layout } from "@/components/layout";
import { Wind, Clock, Coffee } from "lucide-react";
import { motion } from "framer-motion";

export function Methods() {
  const methods = [
    {
      icon: Wind,
      title: "Elpošana",
      description: "2 minūšu elpošanas vingrinājums koncentrēšanās veicināšanai",
      color: "text-blue-400",
      delay: 0.1
    },
    {
      icon: Clock,
      title: "Taimeris",
      description: "Pomodoro metode: mācības 25 minūšu sesijās",
      color: "text-primary",
      delay: 0.2
    },
    {
      icon: Coffee,
      title: "Īsas pauzes",
      description: "Nomainiet 45 minūšu mācības ar 10 minūšu atpūtu.",
      color: "text-secondary",
      delay: 0.3
    }
  ];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-display font-black text-white mb-6">
            Metodes
          </h1>
          <p className="text-xl text-muted-foreground">
            Efektīvi veidi, kā uzlabot produktivitāti
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {methods.map((method, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: method.delay }}
              className="group p-8 rounded-3xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-primary/30 transition-all duration-300 flex flex-col items-center text-center"
            >
              <div className={`w-20 h-20 rounded-full bg-black/50 flex items-center justify-center mb-6 ${method.color} group-hover:scale-110 transition-transform shadow-lg`}>
                <method.icon className="h-10 w-10" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">{method.title}</h3>
              <p className="text-lg text-muted-foreground leading-relaxed">
                "{method.description}"
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </Layout>
  );
}
