import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export function Blog() {
  const posts = [
    {
      id: 1,
      title: "Deep Work: Why Multi-tasking is a Myth",
      excerpt: "Science shows that context switching lowers your IQ by 10 points. Here is how to stop doing it.",
      category: "Science",
      date: "Oct 12, 2024",
      readTime: "5 min read",
      image: "bg-gradient-to-br from-pink-500 to-orange-400"
    },
    {
      id: 2,
      title: "The Perfect Lo-Fi Playlist for Studying",
      excerpt: "We analyzed 10,000 hours of focus sessions to find the optimal BPM for retention.",
      category: "Music",
      date: "Oct 08, 2024",
      readTime: "3 min read",
      image: "bg-gradient-to-br from-blue-500 to-teal-400"
    },
    {
      id: 3,
      title: "Digital Minimalism for Teens",
      excerpt: "How to curate your digital environment to support your goals instead of draining your energy.",
      category: "Lifestyle",
      date: "Oct 01, 2024",
      readTime: "7 min read",
      image: "bg-gradient-to-br from-purple-500 to-indigo-500"
    }
  ];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-20">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-4">
          <div>
            <h1 className="text-4xl md:text-6xl font-display font-black text-white mb-4">
              The <span className="text-primary">Signal</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Insights on focus, productivity, and the brain.
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="rounded-full">Latest</Button>
            <Button variant="ghost" className="rounded-full text-muted-foreground">Popular</Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post) => (
            <article key={post.id} className="group flex flex-col gap-4 cursor-pointer">
              <div className={`aspect-[4/3] rounded-2xl ${post.image} mb-4 opacity-80 group-hover:opacity-100 transition-opacity relative overflow-hidden`}>
                <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors" />
                <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-sm text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider border border-white/10">
                  {post.category}
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
                  <span>{post.date}</span>
                  <span>•</span>
                  <span>{post.readTime}</span>
                </div>
                <h2 className="text-2xl font-bold text-white group-hover:text-primary transition-colors leading-tight">
                  {post.title}
                </h2>
                <p className="text-muted-foreground line-clamp-2">
                  {post.excerpt}
                </p>
                <div className="pt-2 flex items-center text-primary font-bold text-sm opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all">
                  Read Article <ArrowRight className="ml-2 h-4 w-4" />
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </Layout>
  );
}
