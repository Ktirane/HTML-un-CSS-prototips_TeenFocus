import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { FocusTimer } from "@/components/focus-timer";

export function Home() {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-20 min-h-[calc(100vh-4rem)] flex flex-col items-center justify-center">
        <div className="text-center max-w-4xl mx-auto mb-16 animate-in slide-in-from-bottom-10 duration-700">
          <h1 className="text-5xl md:text-8xl font-display font-black text-white mb-6 tracking-tighter">
            Focus<span className="text-primary">Teen</span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
            Vienkārši vingrinājumi pusaudžiem, lai palīdzētu koncentrēties.
          </p>
          
          <Link href="/methods">
            <Button size="lg" className="h-14 px-8 rounded-full text-lg font-bold bg-primary text-black hover:bg-primary/90 hover:scale-105 transition-all shadow-[0_0_30px_hsl(var(--primary)/0.3)]">
              Izmēģiniet to tūlīt
            </Button>
          </Link>
        </div>

        {/* Hero Visual - Using the Timer component as the "Try it now" preview */}
        <div className="w-full max-w-3xl relative animate-in zoom-in-95 duration-1000 delay-300">
          <div className="absolute -top-20 -left-20 w-64 h-64 bg-primary/20 rounded-full blur-[100px] pointer-events-none" />
          <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-secondary/20 rounded-full blur-[100px] pointer-events-none" />
          <FocusTimer />
        </div>
      </div>
    </Layout>
  );
}
