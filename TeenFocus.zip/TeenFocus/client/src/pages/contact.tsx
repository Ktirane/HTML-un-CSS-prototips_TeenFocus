import { Layout } from "@/components/layout";
import { Mail, Instagram, Music } from "lucide-react";

export function Contact() {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-2xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-display font-black text-white mb-12">
            Kontakti
          </h1>

          <div className="space-y-6">
            {/* Email */}
            <div className="bg-white/5 border border-white/10 p-8 rounded-3xl flex flex-col items-center gap-4 hover:bg-white/10 transition-colors">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                <Mail className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white mb-1">Rakstiet mums</h3>
                <p className="text-xl text-primary font-mono">focus@teen.org</p>
              </div>
            </div>

            {/* Socials Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white/5 border border-white/10 p-8 rounded-3xl flex flex-col items-center gap-4 hover:bg-white/10 transition-colors">
                <div className="w-12 h-12 rounded-full bg-pink-500/20 flex items-center justify-center text-pink-500">
                  <Instagram className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">Instagram</h3>
                  <p className="text-xl font-mono">FocusTeen</p>
                </div>
              </div>

              <div className="bg-white/5 border border-white/10 p-8 rounded-3xl flex flex-col items-center gap-4 hover:bg-white/10 transition-colors">
                <div className="w-12 h-12 rounded-full bg-cyan-400/20 flex items-center justify-center text-cyan-400">
                  <Music className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">TikTok</h3>
                  <p className="text-xl font-mono">FocusTeen</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
