import { Layout } from "@/components/layout";
import { Zap, Shield, BarChart, Smartphone, Clock, Headphones } from "lucide-react";
import { motion } from "framer-motion";

export function Features() {
  const features = [
    {
      icon: Clock,
      title: "Smart Timer",
      description: "Customizable Pomodoro intervals that adapt to your flow state.",
      color: "text-primary"
    },
    {
      icon: Headphones,
      title: "Sonic Isolation",
      description: "Curated Lo-Fi and White Noise tracks to block out the world.",
      color: "text-secondary"
    },
    {
      icon: BarChart,
      title: "Progress Analytics",
      description: "Visual data tracking to see when you're most productive.",
      color: "text-blue-400"
    },
    {
      icon: Shield,
      title: "Distraction Blocker",
      description: "Lock away social media apps while your timer is running.",
      color: "text-red-400"
    },
    {
      icon: Smartphone,
      title: "Mobile Sync",
      description: "Seamlessly switch between desktop and mobile without losing your streak.",
      color: "text-amber-400"
    },
    {
      icon: Zap,
      title: "Gamified Streaks",
      description: "Earn badges and levels as you crush your focus goals.",
      color: "text-purple-400"
    }
  ];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-20">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h1 className="text-4xl md:text-6xl font-display font-black text-white mb-6">
            Superpowers for your <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Brain</span>
          </h1>
          <p className="text-xl text-muted-foreground">
            Everything you need to get in the zone and stay there. No fluff, just focus.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group p-8 rounded-3xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-primary/30 transition-all duration-300"
            >
              <div className={`w-12 h-12 rounded-2xl bg-black/50 flex items-center justify-center mb-6 ${feature.color} group-hover:scale-110 transition-transform`}>
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </Layout>
  );
}
